# Código da Transformação - Django 🐍

Este projeto é um exemplo simples usando **Django** para gerenciar produtos.

## Estrutura
- **loja/** → Configurações principais do projeto
- **produtos/** → Aplicação responsável pelo cadastro de produtos

## Modelo Produto
- nome (CharField)
- descrição (TextField)
- preço (DecimalField)
- quantidade (IntegerField)

## Como rodar
1. Clone o repositório:
   ```bash
   git clone https://github.com/seuusuario/Codigo-da-Transformacao-Django.git
   ```
2. Acesse a pasta:
   ```bash
   cd Codigo-da-Transformacao-Django
   ```
3. Crie um ambiente virtual e instale as dependências:
   ```bash
   python -m venv venv
   source venv/bin/activate   # Linux/Mac
   venv\Scripts\activate      # Windows
   pip install -r requirements.txt
   ```
4. Rode as migrações:
   ```bash
   python manage.py migrate
   ```
5. Crie um superusuário:
   ```bash
   python manage.py createsuperuser
   ```
6. Execute o servidor:
   ```bash
   python manage.py runserver
   ```

Acesse [http://127.0.0.1:8000/admin/](http://127.0.0.1:8000/admin/) 🚀
